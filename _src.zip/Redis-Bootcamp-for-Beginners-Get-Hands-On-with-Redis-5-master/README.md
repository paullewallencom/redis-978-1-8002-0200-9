## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/redis-bootcamp-for-beginners-get-hands-on-with-redis-5-video/9781800202009)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Redis-Bootcamp-for-Beginners-Get-Hands-On-with-Redis-5
Redis Bootcamp for Beginners: Get Hands-On with Redis 5 by Packt Publishing
